# ============================================================================
# CELL 2: FOUNDRY CLIENT SUBSCRIPTION INITIALIZATION
# ============================================================================

# --- PYTHON CODE (Executable) ---
# Fetch the connection credentials from your active local shell/Conda environment
FOUNDRY_ENDPOINT = os.getenv("FOUNDRY_PROJECT_ENDPOINT", "https://your-foundry-project.services.ai.azure.com")
MODEL_DEPLOYMENT = os.getenv("FOUNDRY_MODEL_NAME", "gpt-4o")

# Authenticate seamlessly using your active Azure Developer CLI login tokens
azure_credential = DefaultAzureCredential()

# Initialize the centralized underlying Model Client pointing to your Foundry deployment
foundry_client = FoundryChatClient(
    project_endpoint=FOUNDRY_ENDPOINT,
    model=MODEL_DEPLOYMENT,
    credential=azure_credential
)

print(f"Python: Connected to Foundry endpoint using model: {MODEL_DEPLOYMENT}")

# --- .NET (C#) EQUIVALENT (Commented line-by-line) ---
# /*
# // Read environment settings exactly like the Python implementation above
# string foundryEndpoint = Environment.GetEnvironmentVariable("FOUNDRY_PROJECT_ENDPOINT") ?? "https://your-foundry-project.services.ai.azure.com";
# string modelDeployment = Environment.GetEnvironmentVariable("FOUNDRY_MODEL_NAME") ?? "gpt-4o";
# 
# // Instantiates the Azure Identity credential worker for .NET application environments
# var dotnetCredential = new DefaultAzureCredential();
# 
# // Initialize the enterprise .NET Foundry client pointing to your active cloud project
# var dotnetFoundryClient = new FoundryChatClient(
#     new Uri(foundryEndpoint),
#     modelDeployment,
#     dotnetCredential
# );
# 
# Console.WriteLine($".NET: Established cloud connection to {modelDeployment}");
# */