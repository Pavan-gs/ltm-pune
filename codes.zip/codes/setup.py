# Python — conda env (NOT venv, as requested)
conda create -n maf-ecommerce python=3.11 -y
conda activate maf-ecommerce
pip install microsoft-agent-framework
pip install azure-identity azure-ai-projects
pip install azure-search-documents
pip install opentelemetry-sdk python-dotenv httpx
# Verify
python -c "import agent_framework; print('MAF ready')"


# 1. Create a clean Conda environment with Python 3.10+
conda create -n ecom_agent_env python=3.10 -y

# 2. Activate your new Conda environment
conda activate ecom_agent_env

# 3. Install the unified Microsoft Agent Framework production packages
pip install agent-framework agent-framework-foundry azure-identity

# 4. (Optional) Install Jupyter if running this inside an interactive notebook
conda install jupyter -y



'''# .NET — no conda needed, just dotnet CLI
dotnet new console -n EcommerceAgents
cd EcommerceAgents
dotnet add package Microsoft.Agents.AI
dotnet add package Microsoft.Agents.AI.Foundry
dotnet add package Azure.AI.Projects
dotnet add package Azure.Identity
dotnet add package Microsoft.Extensions.Logging.Console'''

AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4o
AZURE_AI_PROJECT_ENDPOINT=https://<foundry-endpoint>
AZURE_AI_SEARCH_ENDPOINT=https://<search>.search.windows.net
AZURE_AI_SEARCH_INDEX=products-index
AZURE_FUNCTIONS_BASE_URL=https://<fn>.azurewebsites.net/api

'''{
  "AZURE_OPENAI_ENDPOINT": "https://<resource>.openai.azure.com/",
  "AZURE_OPENAI_DEPLOYMENT": "gpt-4o",
  "AZURE_AI_PROJECT_ENDPOINT": "https://<foundry-endpoint>",
  "AZURE_AI_SEARCH_ENDPOINT": "https://<search>.search.windows.net",
  "AZURE_AI_SEARCH_INDEX": "products-index",
  "AZURE_FUNCTIONS_BASE_URL": "https://<fn>.azurewebsites.net/api"
}'''