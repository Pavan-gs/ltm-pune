# 1. Create a clean Conda environment with Python 3.10+
conda create -n ecom_agent_env python=3.10 -y

# 2. Activate your new Conda environment
conda activate ecom_agent_env

# 3. Install the unified Microsoft Agent Framework production packages
pip install agent-framework agent-framework-foundry azure-identity

# 4. (Optional) Install Jupyter if running this inside an interactive notebook
conda install jupyter -y