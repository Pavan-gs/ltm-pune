# ############################################################################
# MICROSOFT AGENT FRAMEWORK (MAF) - ENTERPRISE E-COMMERCE WORKSPACE
# Transitioning from Single AI Foundry Functions to Multi-Agent Workflows
# ############################################################################

# ============================================================================
# CELL 1: ENVIRONMENT CONFIGURATION AND CLIENT PACKAGES
# ============================================================================

# --- PYTHON CODE (Executable) ---
import os
import asyncio
from azure.identity import DefaultAzureCredential
# Import the specialized Foundry chat client from the official MAF package
from agent_framework.foundry import FoundryChatClient
# Import core Agent and Workflow building blocks from MAF
from agent_framework import Agent, Message
from agent_framework.workflows import SequentialWorkflow
from agent_framework.tools import system_tool

print("Python: All enterprise MAF packages successfully loaded inside Conda environment.")

# --- .NET (C#) EQUIVALENT (Commented line-by-line) ---
# /*
# // .NET equivalent requires adding the NuGet package: dotnet add package Microsoft.Agents.AI.Foundry --prerelease
# using System;
# using System;
# using System.Threading.Tasks;
# using Azure.Identity;                  // Handles secure Azure Entra ID / CLI token access
# using Microsoft.Agents.AI;              // Core MAF namespace for building Agents
# using Microsoft.Agents.AI.Foundry;      // Connects MAF directly to hosted Azure Foundry instances
# using Microsoft.Agents.AI.Workflows;    // Orchestrates sequential and graph agent execution loops
# 
# Console.WriteLine(".NET: Enterprise namespaces loaded successfully.");
# */