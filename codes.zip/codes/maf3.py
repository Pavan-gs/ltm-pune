# ============================================================================
# CELL 3: FUNCTION TOOL DEFINITIONS (E-commerce Order Lookup mock)
# ============================================================================

# --- PYTHON CODE (Executable) ---
# Use the MAF system_tool decorator to register native source code as an execution capability
@system_tool
def get_order_status(order_id: str) -> str:
    """Queries the internal corporate ERP database to fetch live order tracking logs."""
    # Simulating a database hit for the tutorial demonstration
    if order_id == "ORD-9982":
        return "Status: Shipped. Carrier: FedEx. Current Location: Chicago Distribution Center."
    return f"Status: Processing. Order ID {order_id} verified, pending carrier assignment."

print("Python: get_order_status tool compiled and meta-wrapped successfully.")

# --- .NET (C#) EQUIVALENT (Commented line-by-line) ---
# /*
# // In .NET, we apply a Method Attribute to explicitly define the function as an LLM-callable tool
# [SystemTool("Queries the internal corporate ERP database to fetch live order tracking logs.")]
# public static string GetOrderStatus(string orderId)
# {
#     // Identical programmatic lookup mock matching the Python pipeline execution
#     if (orderId == "ORD-9982")
#     {
#         return "Status: Shipped. Carrier: FedEx. Current Location: Chicago Distribution Center.";
#     }
#     return $"Status: Processing. Order ID {orderId} verified, pending carrier assignment.";
# }
# */