# ============================================================================
# CELL 4: COLLABORATIVE MULTI-AGENT DESIGN AND PIPELINE RUNTIME
# ============================================================================

# --- PYTHON CODE (Executable) ---
async def execute_ecommerce_workflow():
    # Agent 1: Customer Support Triager. Accesses tools to parse the operational state.
    support_agent = Agent(
        name="SupportTriager",
        client=foundry_client,
        instructions="You are front-line support. Use tools to look up order data, then report raw details.",
        tools=[get_order_status]
    )

    # Agent 2: Logistics Concierge. Translates raw telemetry into empathetic updates.
    delivery_concierge = Agent(
        name="DeliveryConcierge",
        client=foundry_client,
        instructions="Take raw status logs and craft an empathetic message. Proactively apologize if delayed."
    )

    # Orchestrate the handoff: SupportTriager retrieves data -> DeliveryConcierge formats the final customer message
    order_pipeline = SequentialWorkflow(name="Order_Fulfillment_Escalation")
    order_pipeline.add_agent(support_agent)
    order_pipeline.add_agent(delivery_concierge)

    # Execute the workflow sequence
    customer_query = "Where is my order ORD-9982? I needed it yesterday!"
    final_response = await order_pipeline.run(input_data=customer_query)
    
    print(f"\n[FINAL PIPELINE OUTPUT TO CUSTOMER]:\n{final_response}")

# Execute the asynchronous engine inside the notebook execution runtime
await execute_ecommerce_workflow()

# --- .NET (C#) EQUIVALENT (Commented line-by-line) ---
# /*
# public static async Task ExecuteEcommerceWorkflowAsync()
# {
#     // Instantiate the primary Support Agent worker in C# using the foundational framework
#     var dotnetSupportAgent = new Agent(
#         name: "SupportTriager",
#         client: dotnetFoundryClient,
#         instructions: "You are front-line support. Use tools to look up order data, then report raw details."
#     );
#     // Register the .NET local method pointer as a functional tool option
#     dotnetSupportAgent.RegisterTool(GetOrderStatus);
# 
#     // Instantiate the downstream delivery messaging specialist agent
#     var dotnetConcierge = new Agent(
#         name: "DeliveryConcierge",
#         client: dotnetFoundryClient,
#         instructions: "Take raw status logs and craft an empathetic message. Proactively apologize if delayed."
#     );
# 
#     // Establish a type-safe sequential state machine chain matching the target architecture
#     var dotnetPipeline = new SequentialWorkflow("Order_Fulfillment_Escalation");
#     dotnetPipeline.AddAgent(dotnetSupportAgent);
#     dotnetPipeline.AddAgent(dotnetConcierge);
# 
#     // Launch the runtime tracking engine asynchronously 
#     string userPrompt = "Where is my order ORD-9982? I needed it yesterday!";
#     var dotnetResult = await dotnetPipeline.RunAsync(userPrompt);
# 
#     Console.WriteLine($"\n[FINAL .NET PIPELINE OUTPUT]:\n{dotnetResult}");
# }
# */